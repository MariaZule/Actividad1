
package actividad1iud;

import java.util.Scanner;

public class Actividad1IUD {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int opcion;
        int cantProductos = 0; //inicializar contadores en 0
        
        Productos[] productos = new Productos[100]; //Arreglo para almacenar los productos
        
        do {
            System.out.println("*******Menú Principal - Inventario*******");
            System.out.println("Selecciona la opción que deseas realizar");
            System.out.println("1. Crear producto");
            System.out.println("2. Mostrar productos del inventario");
            System.out.println("3. Salir");
            opcion = in.nextInt();
                        
            switch (opcion){
                case 1:
                    in.nextLine(); 
                    System.out.println("Crear Producto");
                    System.out.println("Ingrese el código del producto: ");
                    int codigo = in.nextInt();
                    in.nextLine();
                    System.out.println("Ingrese el nombre del producto: ");
                    String nombre = in.nextLine();
                    System.out.println("Ingrese el precio del producto: ");
                    double precio = in.nextDouble();
                    System.out.println("Ingrese la cantidad del producto para inventario: ");
                    int cantidad = in.nextInt();
                    
                    Productos productoNew = new Productos(codigo, nombre, precio, cantidad); //Creación de otra variable que llame a los atributos de la clase, esto para poder agregar los productos
                    
                    productos[cantProductos] = productoNew;
                    cantProductos++;
                    
                    System.out.println("El producto fue creado con éxito.\n");
                    break;
                case 2:
                    System.out.println("\nMostrar Productos en inventario");
                    if (cantProductos > 0) //se verifica si hay productos en el arreglo y prodecemos a ejecutar el ciclo
                        
                    {
                        for (int i = 0; i < cantProductos; i++){
                            productos[i].imprimirProducto();                          
                        }
                        System.out.println("-----------------------");
                        System.out.println("Cantidad total de productos");
                        System.out.println(cantProductos);
                    }
                else{
                        System.out.println("No hay productos para mostrar.\n");  
                    }
                    break;
                case 3:
                    System.out.println("----Saliendo del programa----");
                    break;
                default:
                    System.out.println("Opción inválida. Por favor ingrese una opción válida del menú.\n");
            }
         }while (opcion != 3);
    }   
}
